/*add to ckeditor images attached to the element */
function appendImage(element){

    console.log($(element).prev().html())
    var imgsrc = $(element).prev().attr('src');
    var appendHtml = '<img src=\"'+ imgsrc + '\">';
    CKEDITOR.instances['editor'].insertHtml(appendHtml);


};

var imageJ = [];

for (upload in itemuploads) {

    imageJ.push ({

        type : 'html',
        html : '<img class=\"postImage\" src=\"'+itemuploads[upload]+'\"> <a onclick=\"appendImage(this)\" style=\"background: #3f8edf \" class=\"cke_dialog_ui_button cke_dialog_ui_button_ok\">Add to document</a>'

    });
}



CKEDITOR.dialog.add( 'laragileDialog', function ( editor ) {
    return {
        title: 'Insert Post Images',
        minWidth: 400,
        minHeight: 200,

        //json imageList
        contents: [
            {
                id: 'tab-basic',
                label: 'Images',

                elements: imageJ,
                buttons: [ CKEDITOR.dialog.cancelButton, CKEDITOR.dialog.okButton ]
            }
        ]
    };
});